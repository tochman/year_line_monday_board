import{J as n,a as h,K as pe,L as ie,N as le,O as he,Q as de,T as ve}from"./vendor-DE6FTcl8.js";import{m as ge}from"./monday-vendor-u68qU0GY.js";import{y as se,K as De,k as ce,r as ke,a as Me,i as $e,b as Se,c as Ce,d as ye,N as je}from"./vibe-CT_K7PSJ.js";(function(){const v=document.createElement("link").relList;if(v&&v.supports&&v.supports("modulepreload"))return;for(const g of document.querySelectorAll('link[rel="modulepreload"]'))y(g);new MutationObserver(g=>{for(const p of g)if(p.type==="childList")for(const I of p.addedNodes)I.tagName==="LINK"&&I.rel==="modulepreload"&&y(I)}).observe(document,{childList:!0,subtree:!0});function C(g){const p={};return g.integrity&&(p.integrity=g.integrity),g.referrerPolicy&&(p.referrerPolicy=g.referrerPolicy),g.crossOrigin==="use-credentials"?p.credentials="include":g.crossOrigin==="anonymous"?p.credentials="omit":p.credentials="same-origin",p}function y(g){if(g.ep)return;g.ep=!0;const p=C(g);fetch(g.href,p)}})();window.global||(window.global=window);const Ee=({yearFilter:e,availableYears:v,zoomLevel:C,onYearChange:y,onZoomIn:g,onZoomOut:p,onTodayClick:I})=>{const f=[{value:"all",label:"All Years"},...v.map(u=>({value:String(u),label:String(u)}))],d={month:"Month",week:"Week",day:"Day"};return n.jsxs(se,{justify:"space-between",align:"center",style:{padding:"16px 24px",backgroundColor:"white",borderBottom:"1px solid #e5e7eb"},children:[n.jsxs(se,{gap:"large",align:"center",children:[n.jsx("h2",{style:{fontSize:"20px",fontWeight:"600",margin:0},children:"Gantt Timeline"}),n.jsxs(se,{gap:"medium",align:"center",children:[n.jsx(De,{placeholder:"Select year",options:f,value:f.find(u=>u.value===e),onChange:u=>y(u.value),size:"medium",clearable:!1}),n.jsx(ce,{onClick:I,kind:"tertiary",size:"medium",leftIcon:ke,children:"Today"})]})]}),n.jsxs(se,{gap:"medium",align:"center",children:[n.jsx("span",{style:{fontSize:"14px",color:"#6B7280"},children:"Zoom:"}),n.jsxs(se,{gap:"xs",align:"center",children:[n.jsx(ce,{onClick:p,disabled:C==="month",kind:"tertiary",size:"small",leftIcon:Me,children:"Out"}),n.jsx("span",{style:{padding:"4px 8px",fontSize:"12px",fontWeight:"500",color:"#6B7280",backgroundColor:"#F3F4F6",borderRadius:"4px",minWidth:"60px",textAlign:"center"},children:d[C]}),n.jsx(ce,{onClick:g,disabled:C==="day",kind:"tertiary",size:"small",leftIcon:$e,children:"In"})]})]})]})},_e=({groupedItems:e,expandedGroups:v,selectedItemId:C,groups:y,onToggleGroup:g,onItemClick:p,contentHeight:I})=>{const f=u=>y.find(w=>w.id===u)||{title:"Unknown",color:"#94A3B8"},d=(u,w)=>{const D=f(u),k=v[u],E=w.length;return n.jsxs("div",{style:{borderBottom:"1px solid #e5e7eb"},children:[n.jsxs("div",{onClick:()=>g(u),style:{display:"flex",alignItems:"center",gap:"8px",padding:"0 12px",height:"36px",cursor:"pointer",backgroundColor:"white",transition:"background-color 0.2s"},onMouseEnter:N=>N.currentTarget.style.backgroundColor="#f9fafb",onMouseLeave:N=>N.currentTarget.style.backgroundColor="white",children:[k?n.jsx(Se,{style:{width:"16px",height:"16px",color:"#6B7280"}}):n.jsx(Ce,{style:{width:"16px",height:"16px",color:"#6B7280"}}),n.jsx("div",{style:{width:"12px",height:"12px",borderRadius:"2px",backgroundColor:D.color,flexShrink:0}}),n.jsx("span",{style:{fontWeight:"500",fontSize:"14px",color:"#111827",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:D.title}),n.jsx("span",{style:{fontSize:"12px",color:"#6B7280",backgroundColor:"#F3F4F6",padding:"2px 8px",borderRadius:"4px"},children:E})]}),k&&n.jsx("div",{style:{backgroundColor:"#f9fafb"},children:w.map(N=>n.jsx("div",{onClick:()=>p(N),style:{display:"flex",alignItems:"center",gap:"8px",padding:"0 12px 0 40px",height:"40px",cursor:"pointer",backgroundColor:C===N.id?"#eff6ff":"transparent",borderLeft:C===N.id?"2px solid #3b82f6":"2px solid transparent",transition:"background-color 0.2s"},onMouseEnter:z=>{C!==N.id&&(z.currentTarget.style.backgroundColor="white")},onMouseLeave:z=>{C!==N.id&&(z.currentTarget.style.backgroundColor="transparent")},children:n.jsx("div",{style:{flex:1,minWidth:0},children:n.jsx("div",{style:{fontSize:"14px",color:"#111827",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:N.name})})},N.id))})]},u)};return n.jsx("div",{style:{width:"320px",backgroundColor:"white",borderRight:"1px solid #e5e7eb",flexShrink:0,height:`${I}px`},children:n.jsx("div",{children:Object.keys(e).length===0?n.jsx("div",{style:{padding:"32px 12px",textAlign:"center",fontSize:"14px",color:"#6B7280"},children:"No items to display"}):Object.entries(e).map(([u,w])=>d(u,w))})})},Te=({groupedItems:e,expandedGroups:v,selectedItemId:C,timeScale:y,groups:g,onItemClick:p,onHeaderScroll:I,effectiveWidth:f,scrollRef:d,contentHeight:u})=>{const w=h.useRef(null),D=h.useRef(null),[k,E]=h.useState(0),N=h.useRef(null),z=d||N;h.useEffect(()=>{const O=()=>{w.current&&E(w.current.offsetWidth)};return O(),window.addEventListener("resize",O),()=>window.removeEventListener("resize",O)},[]);const K=36,J=40,L=O=>{const G=g.find(U=>U.id===O);return(G==null?void 0:G.color)||"#94A3B8"},S=(()=>{const{viewStart:O,viewEnd:G}=y,U=[];let R=pe(O);const re=ie(G);for(;R<=re;){const Y=ie(R);U.push({date:R,label:le(R,"MMM"),labelLine2:le(R,"yy"),width:y.dateToX(Y)-y.dateToX(R)}),R=he(R,1)}return U})(),W=f;h.useEffect(()=>{const O=z.current;if(!O||!I)return;const G=()=>{I(O.scrollLeft)};return O.addEventListener("scroll",G),()=>O.removeEventListener("scroll",G)},[I]);const H=u,ne=()=>{const O=[];let G=0;return Object.entries(e).forEach(([U,R])=>{G+=K,v[U]&&(R.forEach((Y,ae)=>{if(!Y.startDate||!Y.endDate)return;const ee=y.dateToX(new Date(Y.startDate)),m=y.dateToX(new Date(Y.endDate)),b=Math.max(m-ee,20),T=G+ae*J+8,Q=L(U),t=C===Y.id;O.push(n.jsxs("g",{onClick:r=>{p&&p(Y,r)},style:{cursor:"pointer"},children:[n.jsx("rect",{x:ee,y:T,width:b,height:24,rx:12,ry:12,fill:Q,opacity:t?1:.9,stroke:t?"#3B82F6":"none",strokeWidth:t?2:0}),n.jsx("text",{x:ee+14,y:T+16,fontSize:"12",fill:"white",style:{pointerEvents:"none",userSelect:"none"},children:Y.name.length>25?Y.name.slice(0,25)+"...":Y.name})]},Y.id))}),G+=R.length*J)}),O},P=y.dateToX(new Date),A=P>=0&&P<=k;return n.jsx("div",{ref:z,style:{flex:1,overflowX:"auto",backgroundColor:"white",minWidth:0,height:`${H}px`},children:n.jsxs("div",{ref:w,style:{position:"relative",height:`${H}px`,width:`${W}px`,minWidth:"100%"},children:[n.jsxs("svg",{ref:D,style:{position:"absolute",inset:0,pointerEvents:"none"},width:W,height:H,children:[S.map((O,G)=>{const U=y.dateToX(O.date);return n.jsx("line",{x1:U,y1:0,x2:U,y2:H,stroke:"#E5E7EB",strokeWidth:1},G)}),A&&n.jsxs(n.Fragment,{children:[n.jsx("line",{x1:P,y1:0,x2:P,y2:H,stroke:"#EF4444",strokeWidth:2,strokeDasharray:"4 2"}),n.jsx("circle",{cx:P,cy:8,r:4,fill:"#EF4444"})]})]}),n.jsx("svg",{style:{position:"absolute",inset:0},width:W,height:H,children:ne()})]})})},Ne=({items:e=[],groups:v=[],yearFilter:C})=>{const y=h.useMemo(()=>e.map(f=>{var w;let d=null,u=null;return(w=f.column_values)==null||w.forEach(D=>{if(D.value)try{if(D.type==="timeline"){const k=JSON.parse(D.value);k.from&&(d=k.from,u=k.to||k.from)}else if(D.type==="date"&&!d){const k=JSON.parse(D.value);k.date&&(d=k.date,u=k.date)}}catch{}}),{...f,startDate:d,endDate:u||d}}).filter(f=>f.startDate),[e]),g=h.useMemo(()=>{const f=new Set;return y.forEach(d=>{d.startDate&&f.add(new Date(d.startDate).getFullYear()),d.endDate&&f.add(new Date(d.endDate).getFullYear())}),[...f].sort((d,u)=>d-u)},[y]),p=h.useMemo(()=>{if(C==="all")return y;const f=parseInt(C,10);return y.filter(d=>{if(!d.startDate||!d.endDate)return!1;const u=new Date(d.startDate).getFullYear(),w=new Date(d.endDate).getFullYear();return u<=f&&w>=f})},[y,C]);return{groupedItems:h.useMemo(()=>{const f={};return v.forEach(d=>{f[d.id]=[]}),p.forEach(d=>{var w;const u=(w=d.group)==null?void 0:w.id;u&&f[u]&&f[u].push(d)}),Object.keys(f).forEach(d=>{f[d].sort((u,w)=>new Date(u.startDate)-new Date(w.startDate))}),f},[p,v]),allItems:p,availableYears:g}},Oe=({viewStart:e,viewEnd:v,containerWidth:C,zoomLevel:y})=>h.useMemo(()=>{const p=(v.getTime()-e.getTime())/(1e3*60*60*24),I=C/p;return{dateToX:w=>((w instanceof Date?w:new Date(w)).getTime()-e.getTime())/(1e3*60*60*24)*I,xToDate:w=>{const k=w/I*(1e3*60*60*24);return new Date(e.getTime()+k)},snapDate:w=>{const D=new Date(w);if(y==="day")D.setHours(0,0,0,0);else if(y==="week"){const k=D.getDay(),E=k===0?-6:1-k;D.setDate(D.getDate()+E),D.setHours(0,0,0,0)}else y==="month"&&(D.setDate(1),D.setHours(0,0,0,0));return D},pixelsPerDay:I,totalDays:p,viewStart:e,viewEnd:v,zoomLevel:y}},[e,v,C,y]),We=({items:e=[],groups:v=[],onUpdateItem:C})=>{const[y,g]=h.useState("all"),[p,I]=h.useState({}),[f,d]=h.useState(null),[u,w]=h.useState(()=>{const m=new Date;return new Date(m.getFullYear(),0,1)}),[D,k]=h.useState(()=>{const m=new Date;return new Date(m.getFullYear(),11,31)}),[E,N]=h.useState("month"),z=h.useRef(null),K=h.useRef(null),J=h.useRef(null),L=h.useRef(null),V=h.useMemo(()=>{const b=(D.getTime()-u.getTime())/(1e3*60*60*24);let T;switch(E){case"day":T=30;break;case"week":T=10;break;case"month":default:T=5;break}return Math.max(800,b*T)},[u,D,E]),{groupedItems:S,availableYears:W}=Ne({items:e,groups:v,yearFilter:y}),H=36,ne=40,P=h.useMemo(()=>{let m=0;return Object.entries(S).forEach(([b,T])=>{m+=H,p[b]&&(m+=T.length*ne)}),Math.max(m,400)},[S,p]);h.useEffect(()=>{Object.keys(S).length>0&&I(m=>{const b={...m};return Object.keys(S).forEach(T=>{b[T]===void 0&&(b[T]=!0)}),b})},[S]),h.useEffect(()=>{if(y==="all"&&W.length>0){const m=Math.min(...W),b=Math.max(...W);w(new Date(m,0,1)),k(new Date(b,11,31))}},[W,y]);const A=Oe({viewStart:u,viewEnd:D,containerWidth:V,zoomLevel:E}),O=h.useMemo(()=>{const m=[];let b=pe(u);const T=ie(D),Q=u.getFullYear(),t=D.getFullYear(),r=y==="all"||Q!==t;for(;b<=T;){const l=ie(b);m.push({date:b,label:le(b,"MMM"),labelLine2:r?le(b,"yy"):null,width:A.dateToX(l)-A.dateToX(b)}),b=he(b,1)}return m},[A,u,D,y]);h.useEffect(()=>{if(!J.current||!A)return;const m=setTimeout(()=>{const b=new Date,T=b.getFullYear(),Q=y==="all"?null:parseInt(y,10);let t;y==="all"||Q===T?t=b:t=new Date(Q,0,1);const r=A.dateToX(t),l=J.current.clientWidth,a=Math.max(0,r-l/3);J.current.scrollTo({left:a,behavior:"smooth"}),K.current&&K.current.scrollTo({left:a,behavior:"smooth"})},100);return()=>clearTimeout(m)},[y,A]);const G=()=>{const m=["month","week","day"],b=m.indexOf(E);b<m.length-1&&N(m[b+1])},U=()=>{const m=["month","week","day"],b=m.indexOf(E);b>0&&N(m[b-1])},R=()=>{const m=new Date,b=new Date(m.getFullYear(),0,1),T=new Date(m.getFullYear(),11,31);w(b),k(T)},re=m=>{if(g(m),m!=="all"){const b=parseInt(m,10);w(new Date(b,0,1)),k(new Date(b,11,31))}else if(W.length>0){const b=Math.min(...W),T=Math.max(...W);w(new Date(b,0,1)),k(new Date(T,11,31))}},Y=m=>{I(b=>({...b,[m]:!b[m]}))},ae=m=>{if(d(m.id),J.current&&m.startDate){const b=J.current,T=A.dateToX(new Date(m.startDate)),Q=m.endDate?A.dateToX(new Date(m.endDate)):T,t=(T+Q)/2,r=b.clientWidth,l=Math.max(0,t-r/2);b.scrollTo({left:l,behavior:"smooth"})}},ee=(m,b)=>{d(m.id)};return n.jsxs("div",{style:{display:"flex",flexDirection:"column",height:"100%",backgroundColor:"#f9fafb"},children:[n.jsx(Ee,{yearFilter:y,availableYears:W,zoomLevel:E,onYearChange:re,onZoomIn:G,onZoomOut:U,onTodayClick:R}),n.jsxs("div",{style:{flexShrink:0,display:"flex",borderBottom:"1px solid #e5e7eb",backgroundColor:"white",position:"sticky",top:0,zIndex:20,boxShadow:"0 1px 2px 0 rgb(0 0 0 / 0.05)"},children:[n.jsx("div",{style:{width:"320px",flexShrink:0,padding:"12px",backgroundColor:"#f3f4f6",borderRight:"1px solid #e5e7eb"},children:n.jsx(ye,{type:"text2",weight:"bold",style:{color:"#374151"},children:"Groups"})}),n.jsx("div",{ref:L,style:{flex:1,overflowX:"hidden",backgroundColor:"#f9fafb",scrollbarWidth:"none",msOverflowStyle:"none"},children:n.jsx("div",{style:{display:"flex",height:"40px",alignItems:"stretch",width:`${V}px`},children:O.map((m,b)=>n.jsxs("div",{style:{flexShrink:0,borderRight:"1px solid #e5e7eb",padding:"4px",textAlign:"center",display:"flex",flexDirection:"column",justifyContent:"center",width:`${m.width}px`},children:[n.jsx("span",{style:{fontSize:"12px",fontWeight:"500",color:"#6B7280",lineHeight:"1.2",overflow:"hidden",textOverflow:"ellipsis"},children:m.label}),m.labelLine2&&n.jsx("span",{style:{fontSize:"10px",color:"#9CA3AF",lineHeight:"1.2"},children:m.labelLine2})]},b))})})]}),n.jsxs("div",{ref:z,style:{flex:1,display:"flex",overflowY:"auto",overflowX:"hidden",position:"relative",minWidth:0},children:[n.jsx(_e,{groupedItems:S,expandedGroups:p,selectedItemId:f,groups:v,onToggleGroup:Y,onItemClick:ae,contentHeight:P}),n.jsx(Te,{groupedItems:S,expandedGroups:p,selectedItemId:f,timeScale:A,groups:v,onItemClick:ee,onHeaderScroll:m=>{L.current&&(L.current.scrollLeft=m)},contentHeight:P,effectiveWidth:V,scrollRef:J})]})]})};function be({size:e="md",className:v=""}){const C={sm:"w-12 h-12",md:"w-20 h-20",lg:"w-32 h-32",xl:"w-48 h-48"},y=(p,I,f,d,u=180,w=180)=>{const D=p*Math.PI/180,k=I*Math.PI/180,E=Math.abs(I-p)>180?1:0,N=u+d*Math.cos(D),z=w+d*Math.sin(D),K=u+d*Math.cos(k),J=w+d*Math.sin(k),L=u+f*Math.cos(k),V=w+f*Math.sin(k),S=u+f*Math.cos(D),W=w+f*Math.sin(D);return`M ${N} ${z} A ${d} ${d} 0 ${E} 1 ${K} ${J} L ${L} ${V} A ${f} ${f} 0 ${E} 0 ${S} ${W} Z`},g=[{start:15,end:42,inner:159,outer:182,color:"#ec4899"},{start:78,end:95,inner:159,outer:182,color:"#06b6d4"},{start:135,end:165,inner:159,outer:182,color:"#8b5cf6"},{start:195,end:218,inner:159,outer:182,color:"#3b82f6"},{start:255,end:275,inner:159,outer:182,color:"#f97316"},{start:310,end:340,inner:159,outer:182,color:"#10b981"},{start:5,end:35,inner:132,outer:154,color:"#3b82f6"},{start:88,end:112,inner:132,outer:154,color:"#f97316"},{start:148,end:172,inner:132,outer:154,color:"#10b981"},{start:208,end:235,inner:132,outer:154,color:"#8b5cf6"},{start:268,end:285,inner:132,outer:154,color:"#ec4899"},{start:318,end:332,inner:132,outer:154,color:"#06b6d4"},{start:22,end:48,inner:104,outer:127,color:"#8b5cf6"},{start:75,end:92,inner:104,outer:127,color:"#ec4899"},{start:125,end:145,inner:104,outer:127,color:"#06b6d4"},{start:185,end:205,inner:104,outer:127,color:"#3b82f6"},{start:235,end:258,inner:104,outer:127,color:"#f97316"},{start:295,end:312,inner:104,outer:127,color:"#10b981"}];return n.jsx("div",{className:`wheel-loader ${C[e]} ${v}`,children:n.jsxs("svg",{viewBox:"0 0 360 360",className:"wheel-loader-svg",children:[n.jsx("style",{children:`
            @keyframes wheel-spin {
              from { transform: rotate(0deg); }
              to { transform: rotate(360deg); }
            }
            @keyframes ring-fade-in {
              from { opacity: 0; transform: scale(0.8); }
              to { opacity: 1; transform: scale(1); }
            }
            @keyframes activity-pop {
              0% { opacity: 0; transform: scale(0); }
              70% { transform: scale(1.1); }
              100% { opacity: 1; transform: scale(1); }
            }
            .wheel-loader-svg {
              animation: wheel-spin 8s linear infinite;
              transform-origin: center;
            }
            .ring-animate {
              animation: ring-fade-in 0.6s ease-out forwards;
              transform-origin: center;
            }
            .activity-animate {
              animation: activity-pop 0.4s ease-out forwards;
              transform-origin: center;
              opacity: 0;
            }
          `}),n.jsx("g",{className:"ring-animate",style:{animationDelay:"0ms"},children:n.jsx("circle",{cx:"180",cy:"180",r:"170",fill:"none",stroke:"#f1f5f9",strokeWidth:"28"})}),n.jsx("g",{className:"ring-animate",style:{animationDelay:"100ms"},children:n.jsx("circle",{cx:"180",cy:"180",r:"142",fill:"none",stroke:"#f8fafc",strokeWidth:"26"})}),n.jsx("g",{className:"ring-animate",style:{animationDelay:"200ms"},children:n.jsx("circle",{cx:"180",cy:"180",r:"114",fill:"none",stroke:"#f1f5f9",strokeWidth:"24"})}),n.jsx("g",{className:"ring-animate",style:{animationDelay:"300ms"},children:n.jsx("circle",{cx:"180",cy:"180",r:"90",fill:"none",stroke:"#e2e8f0",strokeWidth:"12"})}),n.jsx("g",{className:"ring-animate",style:{animationDelay:"400ms"},children:n.jsx("circle",{cx:"180",cy:"180",r:"78",fill:"none",stroke:"#f3f4f6",strokeWidth:"10"})}),g.map((p,I)=>n.jsx("path",{className:"activity-animate",style:{animationDelay:`${500+I*50}ms`},d:y(p.start,p.end,p.inner,p.outer),fill:p.color,opacity:"0.9"},I))]})})}be.propTypes={size:de.oneOf(["sm","md","lg","xl"]),className:de.string};const Je=e=>{try{if(!e)return null;const v=e.split(".");if(v.length!==3)return console.warn("Invalid JWT format"),null;const y=v[1].replace(/-/g,"+").replace(/_/g,"/"),g=decodeURIComponent(atob(y).split("").map(p=>"%"+("00"+p.charCodeAt(0).toString(16)).slice(-2)).join(""));return JSON.parse(g)}catch(v){return console.error("Error decoding JWT:",v),null}},Fe=e=>{if(!e)return!1;const v=Je(e);return v?v.isViewOnly===!0||v.is_view_only===!0:!1},$=ge();var me;const oe=!((me=window.location.ancestorOrigins)!=null&&me.length)&&(window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"),F=oe&&!0;oe&&!F&&$.setToken("eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjU5NzU2Mjk4NCwiYWFpIjoxMSwidWlkIjo5NzM3MDg0MiwiaWFkIjoiMjAyNS0xMi0xNVQwNzoyMToxOS4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6MzI5MTcyNDcsInJnbiI6ImV1YzEifQ.4ThIbEW79wmdiwnXB30by8TEh9Jz3GsjMHPyB0-YXbs");const Ge=[{id:"timeline",title:"Timeline",type:"timerange",settings_str:"{}"},{id:"date",title:"Date",type:"date",settings_str:"{}"},{id:"status",title:"Status",type:"status",settings_str:"{}"},{id:"person",title:"Owner",type:"person",settings_str:"{}"}],we=[{id:"marketing",title:"Marketing",color:"#579bfc"},{id:"development",title:"Development",color:"#9cd326"},{id:"design",title:"Design",color:"#ff642e"},{id:"sales",title:"Sales",color:"#ff5ac4"}],ue=()=>{const e=[],v=["Done","Working on it","Stuck","Not started"],C=["Q1 Planning Session","Product Launch","Team Retreat","Budget Review","Marketing Campaign","Website Redesign","Client Meeting","Sprint Review","Annual Report","Trade Show","Hiring Drive","Training Workshop","Feature Release","Performance Review","Partner Meeting","Strategy Session","User Research","A/B Testing","Content Creation","SEO Optimization","Social Media Campaign","Email Newsletter","Webinar Preparation","Customer Survey","Technical Audit","Security Review","Backup Testing","Server Migration","API Integration","Database Optimization","Code Refactoring","Bug Fixing","UI Improvements","UX Testing","Mobile Optimization","Cross-browser Testing","Documentation Update","Training Material","Onboarding Guide","FAQ Update"],y=parseInt("500")||500,g=new Date().getFullYear(),p=we[0];for(let I=0;I<y;I++){const f=Math.floor(Math.random()*12),d=Math.floor(Math.random()*28)+1,u=new Date(g,f,d),w=`${C[I%C.length]} #${Math.floor(I/C.length)+1}`,D=Math.random()>.6;let k=null;if(D){const z=Math.floor(Math.random()*14)+3;k=new Date(g,f,d+z),k.getFullYear()>g&&(k=new Date(g,11,31))}const E=u.toISOString().split("T")[0],N=k==null?void 0:k.toISOString().split("T")[0];e.push({id:`mock-${I}`,name:w,group:{id:p.id,title:p.title,color:p.color},column_values:[{id:"timeline",type:"timerange",text:N?`${E} - ${N}`:E,value:JSON.stringify({from:E,to:N||E,changed_at:new Date().toISOString()})},{id:"date",type:"date",text:E,value:JSON.stringify({date:E})},{id:"status",type:"status",text:v[Math.floor(Math.random()*v.length)],value:"{}"}]})}return console.log(`📦 Generated ${e.length} mock items in ${g}, group: ${p.title}`),e},Re=()=>{const[e,v]=h.useState(null),[C,y]=h.useState(null),[g,p]=h.useState([]),[I,f]=h.useState([]),[d,u]=h.useState([]),[w,D]=h.useState([]),[k,E]=h.useState(!0),[N,z]=h.useState(null),[K,J]=h.useState(null),[L,V]=h.useState(!1),[S,W]=h.useState({dateColumn:null,endDateColumn:null,statusColumn:null,groupFilter:null,userFilter:null});h.useEffect(()=>{F||$.get("sessionToken").then(t=>{const r=t.data;r&&Fe(r)&&(V(!0),J("viewer_access"),E(!1))}).catch(t=>{console.error("Error fetching session token:",t)})},[]),h.useEffect(()=>{if(F){H();return}if(L)return;let t=null;$.get("context").then(r=>{var l,a,o;r.data&&(v(r.data),t=((l=r.data)==null?void 0:l.boardId)||((o=(a=r.data)==null?void 0:a.boardIds)==null?void 0:o[0]))}),$.listen("context",r=>{var l,a,o;v(r.data),t=((l=r.data)==null?void 0:l.boardId)||((o=(a=r.data)==null?void 0:a.boardIds)==null?void 0:o[0])}),$.listen("settings",r=>{r.data&&W(l=>({...l,...r.data}))}),$.listen("events",r=>{if(window.__skipNextBoardRefetch){window.__skipNextBoardRefetch=!1;return}t&&setTimeout(()=>{P(t)},500)})},[L]);const H=()=>{const t=ue();console.log(`📦 Loading ${t.length} mock items`),p(Ge),u(we),f(t),y({id:"mock-board",name:"Development Board"}),W(r=>({...r,dateColumn:"timeline",statusColumn:"status"})),E(!1)};h.useEffect(()=>{var r;if(F)return;if(!(e!=null&&e.boardId)&&!((r=e==null?void 0:e.boardIds)!=null&&r[0])){const l=setTimeout(()=>{E(!1)},3e3);return()=>clearTimeout(l)}const t=e.boardId||e.boardIds[0];P(t)},[e]);const ne=async()=>{var t;if(F||oe){D([{id:1,name:"Alice Johnson",email:"alice@company.com",photo_thumb:null},{id:2,name:"Bob Smith",email:"bob@company.com",photo_thumb:null},{id:3,name:"Carol Williams",email:"carol@company.com",photo_thumb:null}]);return}try{const l=await $.api(`
        query {
          users {
            id
            name
            email
            photo_thumb
          }
        }
      `);(t=l.data)!=null&&t.users&&D(l.data.users)}catch(r){console.error("Error fetching users:",r),D([])}},P=async t=>{var r,l;E(!0),J(null);try{const o=await $.api(`
        query ($boardId: [ID!]) {
          boards(ids: $boardId) {
            id
            name
            columns {
              id
              title
              type
              settings_str
            }
            groups {
              id
              title
              color
            }
          }
        }
      `,{variables:{boardId:[t]}});if(o.errors&&o.errors.length>0){const s=o.errors.map(i=>i.message).join(", ");if(s.includes("validation")||s.includes("access")||s.includes("permission")){console.warn("Potential viewer access issue:",s),V(!0),J("viewer_access"),E(!1);return}}if((l=(r=o.data)==null?void 0:r.boards)!=null&&l[0]){const s=o.data.boards[0];if(y(s),p(s.columns),u(s.groups),!S.dateColumn){const i=s.columns.find(j=>j.type==="date"),c=s.columns.find(j=>j.type==="timeline"),M=i||c;M&&(W(j=>({...j,dateColumn:M.id})),console.log(`✓ Auto-selected date column: ${M.title} (${M.type})`))}if(!S.statusColumn){const i=s.columns.find(c=>c.type==="status"||c.type==="color");i&&W(c=>({...c,statusColumn:i.id}))}}await ne(),await A(t)}catch(a){console.error("Error fetching board data:",a);const o=a.message||a.toString();o.includes("validation")||o.includes("access")||o.includes("permission")||o.includes("viewer")?(V(!0),J("viewer_access")):J(a.message||"Failed to fetch board data")}finally{E(!1)}},A=async t=>{var r,l,a,o,s;try{let i=[],c=null,M=!0,j=0;const X=500;for(;M;){j++,z(`Loading items (page ${j})...`);const Z=`
          query ($boardId: [ID!], $cursor: String) {
            boards(ids: $boardId) {
              items_page(limit: ${X}, cursor: $cursor) {
                cursor
                items {
                  id
                  name
                  group {
                    id
                    title
                    color
                  }
                  column_values {
                    id
                    type
                    text
                    value
                  }
                }
              }
            }
          }
        `,q={boardId:[t]};c&&(q.cursor=c);const x=await O(async()=>await $.api(Z,{variables:q}));if((a=(l=(r=x.data)==null?void 0:r.boards)==null?void 0:l[0])!=null&&a.items_page){const _=x.data.boards[0].items_page,B=_.items||[];console.log(`📄 Page ${j}: Fetched ${B.length} items, cursor: ${_.cursor?"exists":"null"}`),i=[...i,...B],c=_.cursor,M=!!c,console.log(`📊 Total items so far: ${i.length}, hasMore: ${M}`),M&&await new Promise(te=>setTimeout(te,200))}else M=!1}f(i),z(null),console.log(`✓ Loaded ${i.length} items from board`)}catch(i){console.error("Error fetching items:",i),z(null),(o=i.message)!=null&&o.includes("complexity")||(s=i.message)!=null&&s.includes("rate limit")?J("Rate limit exceeded. Please try again in a moment."):J(i.message||"Failed to fetch items")}},O=async(t,r=3)=>{var l,a;for(let o=0;o<r;o++)try{return await t()}catch(s){if((((l=s.message)==null?void 0:l.includes("complexity"))||((a=s.message)==null?void 0:a.includes("rate limit"))||s.status===429)&&o<r-1){const c=Math.pow(2,o)*1e3;console.log(`Rate limit hit, retrying in ${c}ms...`),await new Promise(M=>setTimeout(M,c))}else throw s}},G=h.useCallback(()=>{if(I.length===0)return[];const t=g.filter(o=>o.type==="date"||o.type==="timeline"),r=S.endDateColumn?g.find(o=>o.id===S.endDateColumn):null,l=S.statusColumn?g.find(o=>o.id===S.statusColumn):null;let a=null;return S.dateColumn?a=g.find(o=>o.id===S.dateColumn):a=t.find(o=>o.type==="date")||t.find(o=>o.type==="timeline"),a?I.map(o=>{let s=null,i=null,c=null;const M=o.column_values.find(x=>x.id===a.id);if(M!=null&&M.value)try{if(a.type==="timeline"){const x=JSON.parse(M.value);x.from&&(s=x.from,i=x.to||null,c=a.title)}else if(a.type==="date"){const x=JSON.parse(M.value);x.date&&(s=x.date,c=a.title)}}catch(x){console.warn(`Error parsing ${a.type} for ${o.name}:`,x)}if(!s)for(const x of t){if(x.id===a.id)continue;const _=o.column_values.find(B=>B.id===x.id);if(_!=null&&_.value)try{if(x.type==="timeline"){const B=JSON.parse(_.value);if(B.from){s=B.from,i=B.to||null,c=x.title;break}}else if(x.type==="date"){const B=JSON.parse(_.value);if(B.date){s=B.date,c=x.title;break}}}catch{}}if(r&&!i){const x=o.column_values.find(_=>_.id===r.id);if(x!=null&&x.value)try{if(r.type==="timeline"){const _=JSON.parse(x.value);i=_.to||_.from}else r.type==="date"&&(i=JSON.parse(x.value).date)}catch(_){console.warn(`Error parsing end date for ${o.name}:`,_)}}if(!s)return null;let j=null;if(l){const x=o.column_values.find(_=>_.id===l.id);x!=null&&x.text&&(j=x.text)}const X=o.column_values.filter(x=>x.type==="people"),Z=[],q=[];return X.forEach(x=>{if(x!=null&&x.value)try{const _=JSON.parse(x.value);_.personsAndTeams&&_.personsAndTeams.forEach(B=>{if(B.id&&B.kind==="person"){Z.push(B.id);const te=w.find(xe=>xe.id===B.id);te&&q.push({id:te.id,name:te.name,email:te.email,photo:te.photo_thumb})}})}catch(_){console.warn(`Error parsing Person column for ${o.name}:`,_)}}),S.userFilter&&(Z.length===0||!Z.includes(parseInt(S.userFilter)))||S.groupFilter&&o.group.id!==S.groupFilter?null:{id:o.id,name:o.name,startDate:s,endDate:i||s,status:j,assignedUsers:q,assignedUserIds:Z,group:o.group,groupColor:o.group.color}}).filter(Boolean):(console.warn("No date or timeline columns available"),[])},[I,g,w,S]),U=h.useCallback(t=>{if(F){alert(`Item: ${t}

In Monday.com, this would open the item card.`);return}$.execute("openItemCard",{itemId:parseInt(t)})},[]),R=h.useCallback(()=>{var t;if(F){f(ue());return}if(e!=null&&e.boardId||(t=e==null?void 0:e.boardIds)!=null&&t[0]){const r=e.boardId||e.boardIds[0];P(r)}},[e]),re=async(t,r,l)=>{var a;if(f(o=>o.map(s=>{if(s.id===t){const i={...s};return i.column_values=i.column_values.map(c=>c.type==="timeline"&&l&&l!==r?{...c,value:JSON.stringify({from:r,to:l}),text:`${r} - ${l}`}:c.type==="date"?{...c,value:JSON.stringify({date:r}),text:r}:c),i}return s})),F||oe)return{success:!0,mock:!0};try{const o=g.find(c=>c.type==="timeline"),s=g.find(c=>c.type==="date"),i=(e==null?void 0:e.boardId)||((a=e==null?void 0:e.boardIds)==null?void 0:a[0]);if(!i)throw new Error("No board ID available");if(window.__skipNextBoardRefetch=!0,o&&l&&l!==r){const c=`
          mutation (
            $boardId: ID!,
            $itemId: ID!,
            $columnId: String!,
            $value: JSON!
          ) {
            change_column_value(
              board_id: $boardId,
              item_id: $itemId,
              column_id: $columnId,
              value: $value
            ) {
              id
            }
          }
        `,M={boardId:parseInt(i),itemId:parseInt(t),columnId:o.id,value:JSON.stringify({from:r,to:l})},j=await $.api(c,{variables:M});return{success:!0,column:"Timeline",startDate:r,endDate:l}}else if(s){const c=`
          mutation (
            $boardId: ID!,
            $itemId: ID!,
            $columnId: String!,
            $value: JSON!
          ) {
            change_column_value(
              board_id: $boardId,
              item_id: $itemId,
              column_id: $columnId,
              value: $value
            ) {
              id
            }
          }
        `,M={boardId:parseInt(i),itemId:parseInt(t),columnId:s.id,value:JSON.stringify({date:r})},j=await $.api(c,{variables:M});return{success:!0,column:"Date",startDate:r}}else throw new Error("No date or timeline column found")}catch(o){throw console.error("❌ Error updating item:",o),$.execute("notice",{message:"Failed to update item: "+o.message,type:"error",timeout:3e3}),o}},Y=async(t,r)=>{var l;if(F||oe)return{success:!0,mock:!0};try{if(!((e==null?void 0:e.boardId)||((l=e==null?void 0:e.boardIds)==null?void 0:l[0])))throw new Error("No board ID available");const o=`
        mutation (
          $itemId: ID!,
          $groupId: String!
        ) {
          move_item_to_group(
            item_id: $itemId,
            group_id: $groupId
          ) {
            id
          }
        }
      `,s={itemId:parseInt(t),groupId:r};return await $.api(o,{variables:s}),f(i=>i.map(c=>{if(c.id===t){const M=d.find(j=>j.id===r);if(M)return{...c,group:M}}return c})),{success:!0,groupId:r}}catch(a){throw console.error("❌ Error updating item group:",a),$.execute("notice",{message:"Failed to move item: "+a.message,type:"error",timeout:3e3}),a}},ae=async(t,r)=>{var l;if(F||oe)return{success:!0,mock:!0};try{const a=(e==null?void 0:e.boardId)||((l=e==null?void 0:e.boardIds)==null?void 0:l[0]);if(!a)throw new Error("No board ID available");const o=`
        mutation (
          $boardId: ID!,
          $itemId: ID!,
          $columnId: String!,
          $value: String!
        ) {
          change_simple_column_value(
            board_id: $boardId,
            item_id: $itemId,
            column_id: $columnId,
            value: $value
          ) {
            id
            name
          }
        }
      `,s={boardId:parseInt(a),itemId:parseInt(t),columnId:"name",value:r};return await $.api(o,{variables:s}),window.__skipNextBoardRefetch=!0,f(i=>i.map(c=>c.id===t?{...c,name:r}:c)),{success:!0,newName:r}}catch(a){throw console.error("❌ Error updating item name:",a),$.execute("notice",{message:"Failed to update name: "+a.message,type:"error",timeout:3e3}),a}},ee=h.useCallback(async(t,r="inner")=>{var a,o;if(F){const s={id:`group-${Date.now()}`,title:t,color:"#579bfc",ringType:r};return u(i=>[...i,s]),s}const l=(e==null?void 0:e.boardId)||((a=e==null?void 0:e.boardIds)==null?void 0:a[0]);if(!l)throw new Error("No board selected");try{const s=`
        mutation ($boardId: ID!, $groupName: String!) {
          create_group (
            board_id: $boardId,
            group_name: $groupName
          ) {
            id
            title
            color
          }
        }
      `,i={boardId:parseInt(l),groupName:t},c=await $.api(s,{variables:i});if((o=c.data)!=null&&o.create_group){const j={...c.data.create_group,ringType:r};return u(X=>[...X,j]),$.execute("notice",{message:`Group "${t}" created successfully`,type:"success",timeout:2e3}),j}throw new Error("Failed to create group")}catch(s){throw console.error("❌ Error creating group:",s),$.execute("notice",{message:"Failed to create group: "+s.message,type:"error",timeout:3e3}),s}},[e,F]),m=h.useCallback(async(t,r)=>{var a,o;if(F)return u(s=>s.map(i=>i.id===t?{...i,title:r.name||i.title,color:r.color||i.color}:i)),{id:t,title:r.name,color:r.color};const l=(e==null?void 0:e.boardId)||((a=e==null?void 0:e.boardIds)==null?void 0:a[0]);if(!l)throw new Error("No board selected");try{const s=`
        mutation ($boardId: ID!, $groupId: String!, $groupAttribute: GroupAttributes!, $newValue: String!) {
          update_group (
            board_id: $boardId,
            group_id: $groupId,
            group_attribute: $groupAttribute,
            new_value: $newValue
          ) {
            id
            title
            color
          }
        }
      `;let i;if(r.name){const c={boardId:parseInt(l),groupId:t,groupAttribute:"title",newValue:r.name};i=await $.api(s,{variables:c})}if(r.color){const c={boardId:parseInt(l),groupId:t,groupAttribute:"color",newValue:r.color};i=await $.api(s,{variables:c})}if((o=i==null?void 0:i.data)!=null&&o.update_group){const c=i.data.update_group;return u(M=>M.map(j=>j.id===t?c:j)),$.execute("notice",{message:"Group updated successfully",type:"success",timeout:2e3}),c}throw new Error("Failed to update group")}catch(s){throw console.error("❌ Error updating group:",s),$.execute("notice",{message:"Failed to update group: "+s.message,type:"error",timeout:3e3}),s}},[e,F]),b=h.useCallback(async(t,r)=>{var a;if(F||oe)return{success:!0,mock:!0};const l=(e==null?void 0:e.boardId)||((a=e==null?void 0:e.boardIds)==null?void 0:a[0]);if(!l)throw new Error("No board selected");try{const o=g.find(M=>M.type==="people");if(!o)throw new Error("No Person column found on this board");const s={personsAndTeams:r.map(M=>({id:parseInt(M),kind:"person"}))},i=`
        mutation (
          $boardId: ID!,
          $itemId: ID!,
          $columnId: String!,
          $value: JSON!
        ) {
          change_column_value(
            board_id: $boardId,
            item_id: $itemId,
            column_id: $columnId,
            value: $value
          ) {
            id
          }
        }
      `,c={boardId:parseInt(l),itemId:parseInt(t),columnId:o.id,value:JSON.stringify(s)};return window.__skipNextBoardRefetch=!0,await $.api(i,{variables:c}),f(M=>M.map(j=>j.id===t?{...j,column_values:j.column_values.map(X=>X.id===o.id?{...X,value:JSON.stringify(s),text:r.map(Z=>{var q;return(q=w.find(x=>x.id===parseInt(Z)))==null?void 0:q.name}).filter(Boolean).join(", ")}:X)}:j)),$.execute("notice",{message:"User assignment updated successfully",type:"success",timeout:2e3}),{success:!0}}catch(o){throw console.error("❌ Error updating user assignment:",o),$.execute("notice",{message:"Failed to update user assignment: "+o.message,type:"error",timeout:3e3}),o}},[e,g,w,F]),T=h.useCallback(async t=>{var l,a,o,s,i;if(console.log("🗑️ Attempting to delete group:",t,"Current groups state:",d.length,d),F){if(d.length<=1)throw $.execute("notice",{message:"Cannot delete the last group. Boards must have at least one group.",type:"error",timeout:3e3}),new Error("Cannot delete last group - board has to have at least one group");return u(c=>c.filter(M=>M.id!==t)),{success:!0}}const r=(e==null?void 0:e.boardId)||((l=e==null?void 0:e.boardIds)==null?void 0:l[0]);if(!r)throw new Error("No board selected");try{const j=((s=(o=(a=(await $.api(`
        query ($boardId: [ID!]) {
          boards(ids: $boardId) {
            groups {
              id
              title
            }
          }
        }
      `,{variables:{boardId:[parseInt(r)]}})).data)==null?void 0:a.boards)==null?void 0:o[0])==null?void 0:s.groups)||[];if(console.log("✅ Current groups from Monday.com:",j.length,j),j.length<=1)throw $.execute("notice",{message:"Cannot delete the last group. Boards must have at least one group.",type:"error",timeout:3e3}),new Error("Cannot delete last group - board has to have at least one group");const X=`
        mutation ($boardId: ID!, $groupId: String!) {
          delete_group (
            board_id: $boardId,
            group_id: $groupId
          ) {
            id
            deleted
          }
        }
      `,Z={boardId:parseInt(r),groupId:t};if((i=(await $.api(X,{variables:Z})).data)!=null&&i.delete_group)return u(x=>x.filter(_=>_.id!==t)),$.execute("notice",{message:"Group deleted successfully",type:"success",timeout:2e3}),{success:!0};throw new Error("Failed to delete group")}catch(c){throw console.error("❌ Error deleting group:",c),$.execute("notice",{message:"Failed to delete group: "+c.message,type:"error",timeout:3e3}),c}},[e,F]),Q=h.useCallback(async t=>{var r,l;if(F){console.log("📝 Mock: Creating item",t);const a={id:`mock-${Date.now()}`,name:t.name,group:d.find(o=>o.id===t.groupId),column_values:[{id:S.dateColumn||"date",type:"date",text:t.startDate,value:JSON.stringify({date:t.startDate})}]};return t.endDate&&a.column_values.push({id:S.endDateColumn||"timeline",type:"timerange",text:`${t.startDate} - ${t.endDate}`,value:JSON.stringify({from:t.startDate,to:t.endDate})}),f(o=>[...o,a]),{success:!0,item:a,mock:!0}}try{const a=(e==null?void 0:e.boardId)||((r=e==null?void 0:e.boardIds)==null?void 0:r[0]);if(!a)throw new Error("No board ID available");const o={};S.dateColumn&&t.startDate&&(o[S.dateColumn]={date:t.startDate}),S.endDateColumn&&t.endDate&&(o[S.endDateColumn]={from:t.startDate,to:t.endDate});const i=await $.api(`
        mutation ($boardId: ID!, $groupId: String!, $itemName: String!, $columnValues: JSON!) {
          create_item(
            board_id: $boardId,
            group_id: $groupId,
            item_name: $itemName,
            column_values: $columnValues
          ) {
            id
            name
          }
        }
      `,{variables:{boardId:parseInt(a),groupId:t.groupId,itemName:t.name,columnValues:JSON.stringify(o)}});if((l=i.data)!=null&&l.create_item)return console.log("✅ Item created:",i.data.create_item),$.execute("notice",{message:`Item "${t.name}" created successfully`,type:"success",timeout:3e3}),await R(),{success:!0,item:i.data.create_item};throw new Error("No item returned from create_item mutation")}catch(a){return console.error("❌ Failed to create item:",a),$.execute("notice",{message:`Failed to create item: ${a.message}`,type:"error",timeout:5e3}),{success:!1,error:a.message}}},[e,S,d,$,R]);return{context:e,boardData:C,columns:g,groups:d,items:I,users:w,settings:S,setSettings:W,loading:k,loadingProgress:N,error:K,isViewerUser:L,wheelItems:G(),openItem:U,refresh:R,updateItemDates:re,updateItemGroup:Y,updateItemName:ae,updateItemUsers:b,createItem:Q,createGroup:ee,updateGroup:m,deleteGroup:T}},Ie=ge();var fe;const Be=!((fe=window.location.ancestorOrigins)!=null&&fe.length)&&(window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1");Be&&Ie.setToken("eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjU5NzU2Mjk4NCwiYWFpIjoxMSwidWlkIjo5NzM3MDg0MiwiaWFkIjoiMjAyNS0xMi0xNVQwNzoyMToxOS4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6MzI5MTcyNDcsInJnbiI6ImV1YzEifQ.4ThIbEW79wmdiwnXB30by8TEh9Jz3GsjMHPyB0-YXbs");const ze=()=>{const{loading:e,error:v,items:C,groups:y,updateItemDates:g}=Re();h.useEffect(()=>{Ie.execute("valueCreatedForUser")},[]);const p=h.useCallback(async I=>{if(I&&I.id){const f=I.startDate,d=I.endDate;if(d&&f&&d<f){console.warn("End date before start date, skipping update");return}await g(I.id,f,d)}},[g]);return e?n.jsx("div",{style:{display:"flex",justifyContent:"center",alignItems:"center",height:"100vh"},children:n.jsx(be,{})}):v?n.jsx(je,{padding:"large",children:n.jsxs(ye,{type:"text1",color:"negative",children:["Error loading board data: ",v]})}):n.jsx("div",{style:{height:"100vh",display:"flex",flexDirection:"column"},children:n.jsx(We,{items:C,groups:y,onUpdateItem:p})})};window.location.hostname==="localhost"||window.location.hostname==="[::1]"||window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/);function Ye(){"serviceWorker"in navigator&&navigator.serviceWorker.ready.then(e=>{e.unregister()}).catch(e=>{console.error(e.message)})}const Ue=ve.createRoot(document.getElementById("root"));Ue.render(n.jsx(ze,{}));Ye();
